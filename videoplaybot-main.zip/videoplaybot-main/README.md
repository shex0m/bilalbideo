## 🛠 فەرمانەکان:
- /playv لەڕیپڵەی ڤیدیۆ یان لینکی یوتوب
- /vstop بۆ ڕاگرتنی پەخشکردن
- /audio ناووی گۆرانی بۆ دابەزاندنی گۆرانی
- /video ناووی ڤیدیۆ بۆ دابەزاندنی ڤیدیۆ



## 🧪 Get STRING_SESSION from below:

بڕۆ ئێرە: [![GenerateString](https://img.shields.io/badge/repl.it-generateString-yellowgreen)](https://replit.com/@Kurd-Bots/StringSession#main.py)

## Heroku Deployment 💜
بۆ کاراکردن...

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/kurd-bots/videoplaybot)


### بۆ پگشیری و یارمەتی 🎑
<a href="https://t.me/Kurd_BotsChat"><img src="https://img.shields.io/badge/Join-Group%20Support-blue.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/Kurd_Help"><img src="https://img.shields.io/badge/Join-Updates%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
