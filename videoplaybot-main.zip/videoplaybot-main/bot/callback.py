from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery

from config import ASSISTANT_NAME as bn
from config import CHANNEL, GROUP

@Client.on_callback_query(filters.regex("cbguide"))
async def cbguide(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""**❓ چۆن من بەکاردەهێنیت:

1.) سەرەتا زیادی گرووپم بکە .
2.) دواتر هەموو دەسەڵاتێکم بدێ جگە ئەدمینی نەناسراوو.
3.) دواتر یارمەتی دەر @{bn} زیادی گرووپ بکە.
4.) پاشان ڤیدیۆ چات دەست پێ بکە.
**""",
        reply_markup=InlineKeyboardMarkup(
            [[
                InlineKeyboardButton(
                    "🏡 ", callback_data="cbstart")
            ]]
        ))


@Client.on_callback_query(filters.regex("cbstart"))
async def cbstart(_, query: CallbackQuery):
    await query.edit_message_text(
        f" **✨ ❤️‍🩹سڵاوو، من بۆتی پەخشکردنی ڤیدیۆم لە ڤیدیۆ چاتی گرووپەکان لەتیڵیگرام .\n☑️من بۆ پەخشکردنی ڤیدیۆ لەڤیدیۆ چاتی گرووپەکەت بۆ سەیرکردنی فلیم و هتد ، ئەتوانی بەکارم بێنیت.. \n🤔چۆنیەتی کارکردنم کرتە بکە لەسەر دووگمەی خوارەوە 👇**",
        reply_markup=InlineKeyboardMarkup(
            [[
                InlineKeyboardButton(
                    "❔ چۆن من بەکاردەهێنیت", callback_data="cbguide")
            ], [
                InlineKeyboardButton(
                    "💬 گرووپ", url=f"https://t.me/{GRUOP}"),
                InlineKeyboardButton(
                    "📣 کەناڵ", url=f"https://t.me/{CHANNEL}")
            ],[
                InlineKeyboardButton(
                    "📚 فەرمانەکان", callback_data="cblist")
            ]]
        ))


@Client.on_callback_query(filters.regex("cblist"))
async def cblist(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""**📚 فەرمانەکان:
» /playv (لە ڕیپڵەی ڤیدیۆ یان فایل) - بۆ پەخشکردنی ڤیدیۆیان لینکی ڤیدیۆی یوتوب
» /vstop - بۆ ڕاگرتنی پەخشکردن
» /audio (ناووی گۆرانی) - بۆ دابەزاندنی گۆرانی لە یوتوب
» /video (ناووی ڤیدیۆ) - بۆ دابەزاندنی ڤیدیۆ لە یوتوب**""",
        reply_markup=InlineKeyboardMarkup(
            [[
                InlineKeyboardButton(
                    "🏡 ", callback_data="cbstart")
            ]]
        ))


@Client.on_callback_query(filters.regex("cls"))
async def close(_, query: CallbackQuery):
    await query.message.delete()
