from os import path, getenv
from dotenv import load_dotenv

if path.exists("local.env"):
    load_dotenv("local.env")

load_dotenv()
admins = {}
BOT_TOKEN = getenv("BOT_TOKEN", None)
API_ID = int(getenv("API_ID", "6834740"))
API_HASH = getenv("API_HASH", "22130e5a0fe453b50971616752d2fb47")
SESSION_NAME = getenv("SESSION_NAME", None)
DURATION_LIMIT = int(getenv("DURATION_LIMIT", "15"))
SUDO_USERS = list(map(int, getenv("SUDO_USERS").split()))
ASSISTANT_NAME = getenv("ASSISTANT_NAME", "AmortAssistant")
BOT_USERNAME = getenv("BOT_USERNAME", "AmortVideoBot")
GROUP = getenv("GROUP", "Kurd_Botschat")
CHANNEL = getenv("CHANNEL", "AmortVideo")
COMMAND_PREFIXES = list(getenv("COMMAND_PREFIXES", "/ ! .").split())
